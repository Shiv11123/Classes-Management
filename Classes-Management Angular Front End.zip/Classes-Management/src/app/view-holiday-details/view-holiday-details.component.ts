import { Component, OnInit } from '@angular/core';
import { Holiday } from '../holiday';  
import{HolidayService} from '../holiday.service';
import { Observable,Subject } from "rxjs";  
import {FormControl,FormGroup,Validators} from '@angular/forms';  
import { AdminloginService } from '../adminlogin.service';
@Component({
  selector: 'app-view-holiday-details',
  templateUrl: './view-holiday-details.component.html',
  styleUrls: ['./view-holiday-details.component.css']
})
export class ViewHolidayDetailsComponent implements OnInit {

  constructor(private holidayservice:HolidayService, public authservice:AdminloginService) { }
  holidaysArray: any[] = [];  
  holidays: Observable<Holiday[]>; 
  holiday:Holiday=new Holiday();

  deleteMessage=false;  
  holidaylist:any;  
  isupdated = false;

  searchText;

  ngOnInit(): void {

    console.log("inside oninit");
    this.holidayservice.getHolidayList().subscribe(data =>{  
      this.holidays =data;
      console.log(data);
    }) 

  }

  deleteHoliday(id: number) {  
    this.holidayservice.deleteHoliday(id)  
      .subscribe(  
        data => {  
          console.log(data);  
          this.deleteMessage=true;  
          this.holidayservice.getHolidayList().subscribe(data =>{  
            this.holidays =data  
            })  
        },  
        error => console.log(error));  
  }  
  
  updateHoliday(holiday_id: number){  
    this.holidayservice.getHoliday(holiday_id)  
      .subscribe(  
        data => {  
          console.log(data)
          this.holidaylist=Array.of(data)             
        },  
        error => console.log(error));  
  }  
  
  holidayupdateform=new FormGroup({  
    holiday_id:new FormControl(),  
    holiday_reason:new FormControl(),  
    holiday_date:new FormControl(),  
  });  
  
  updateHoli(updholi){  
    this.holiday=new Holiday();     
    this.holiday.holiday_id=this.HolidayId.value; 
    this.holiday.holiday_reason=this.HolidayReason.value;  
    this.holiday.holiday_date=this.HolidayDate.value;  
  
   console.log(this.HolidayReason.value);  
     
   this.holidayservice.updateHoliday(this.holiday.holiday_id,this.holiday).subscribe(  
    data => {       
      this.isupdated=true;  
      this.holidayservice.getHolidayList().subscribe(data =>{  
        this.holidays =data  
        })  
    },  
    error => console.log(error));  
  }  

  get HolidayId(){  
    return this.holidayupdateform.get('holiday_id');  
  }  

  get HolidayReason(){  
    return this.holidayupdateform.get('holiday_reason');  
  }  
  
  get HolidayDate(){  
    return this.holidayupdateform.get('holiday_date');  
  }  
  
  changeisUpdate(){  
    this.isupdated=false;  
  } 
  


}
