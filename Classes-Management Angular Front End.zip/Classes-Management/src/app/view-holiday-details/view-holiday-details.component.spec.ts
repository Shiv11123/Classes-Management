import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewHolidayDetailsComponent } from './view-holiday-details.component';

describe('ViewHolidayDetailsComponent', () => {
  let component: ViewHolidayDetailsComponent;
  let fixture: ComponentFixture<ViewHolidayDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewHolidayDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewHolidayDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
