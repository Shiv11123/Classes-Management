export class Login {
    login_id:number;
    uname:String;
    password:String;
    login_type:String;
}
