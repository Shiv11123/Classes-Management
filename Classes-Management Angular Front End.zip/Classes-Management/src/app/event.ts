export class Event {
    event_id:number;
    event_name:String;
    event_description:String;
    event_date:Date;
    event_start_time:String;
    event_end_time:String;
}
