import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddLectureDetailsComponent } from './add-lecture-details.component';

describe('AddLectureDetailsComponent', () => {
  let component: AddLectureDetailsComponent;
  let fixture: ComponentFixture<AddLectureDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddLectureDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddLectureDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
