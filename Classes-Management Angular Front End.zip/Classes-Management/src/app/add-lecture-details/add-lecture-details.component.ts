import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import getISOWeek from 'date-fns/getISOWeek';
import { en_US, NzI18nService, zh_CN } from 'ng-zorro-antd/i18n';
import { LectureService } from '../lecture.service';
import { Lecture } from '../lecture';
import {Router} from '@angular/router';
import * as moment from 'moment';


@Component({
  selector: 'app-add-lecture-details',
  templateUrl: './add-lecture-details.component.html',
  styleUrls: ['./add-lecture-details.component.css'],
  
  
})
export class AddLectureDetailsComponent implements OnInit {
    
  date = null;
  dateRange = [];
  isEnglish = false;

  time: Date | null = null;
  time1: Date | null = null;

  lecturesaveform!: FormGroup;
  controlArray: Array<{ index: number; show: boolean }> = [];
  isCollapse = true;

  constructor(private fb: FormBuilder,private i18n: NzI18nService,private lectureservice:LectureService, private router:Router) {}

  //  redirect1() {
  //    this.router.navigate(['/view-lecture-details/']);
  //  }

lecture : Lecture = new Lecture();
types:Lecture[];
submitted=false;

  ngOnInit(): void {
    this.lecturesaveform = this.fb.group({
    lecture_id:new FormControl(''),
    lecture_name:new FormControl('' , [Validators.required , Validators.minLength(3) ] ),
    faculty_name:new FormControl('' , [Validators.required ]),
    lecture_date:new FormControl('' , [Validators.required ] ),
    lecture_start_time:new FormControl('' , [Validators.required ] ),
    lecture_end_time:new FormControl('' , [Validators.required ]),
    });

    for (let i = 0; i < 10; i++) {
      this.controlArray.push({ index: i, show: i < 6 });
      this.lecturesaveform.addControl(`field${i}`, new FormControl());
      this.submitted=false;
    }
    
  }

  toggleCollapse(): void {
    this.isCollapse = !this.isCollapse;
    this.controlArray.forEach((c, index) => {
      c.show = this.isCollapse ? index < 6 : true;
    });
  }

  onChange(result: Date): void {
    console.log('onChange: ', result);
  }
  getWeek(result: Date): void {
    console.log('week: ', getISOWeek(result));
  }

  changeLanguage(): void {
    this.i18n.setLocale(this.isEnglish ? zh_CN : en_US);
    this.isEnglish = !this.isEnglish;
  }

  saveLecture(saveLecture){
    this.lecture=new Lecture();
    this.lecture.lecture_id=this.LectureId.value;
    this.lecture.lecture_name=this.LectureName.value;
    this.lecture.faculty_name=this.FacultyName.value;
    this.lecture.lecture_date=this.LectureDate.value;
    this.lecture.lecture_start_time=moment(this.LectureStartTime.value).format("hh:mm A");
    this.lecture.lecture_end_time=moment(this.LectureEndTime.value).format("hh:mm A");

    this.submitted = true;
    this.save();
    }

    save() {  
      console.log(JSON.stringify(this.lecture))
      this.lectureservice.createLecture(this.lecture)  
        .subscribe(data => console.log(data), error => console.log(error));  
      this.lecture = new Lecture();  
    }  
    

      get LectureId(){
          return this.lecturesaveform.get("lecture_id");
      }

      get LectureName(){
        return this.lecturesaveform.get("lecture_name");
      }

      get FacultyName(){
        return this.lecturesaveform.get("faculty_name");
      }

      get LectureDate(){
        return this.lecturesaveform.get("lecture_date");
      }

      get LectureStartTime(){
        return this.lecturesaveform.get("lecture_start_time");
      }

      get LectureEndTime(){
        return this.lecturesaveform.get("lecture_end_time");
      }


      addLectureForm(){
        this.submitted=false;
        this.lecturesaveform.reset();
      }


/*   resetForm(): void {
    this.validateForm.reset();
  }



  lecturesaveform = new FormGroup({

  }); */

      


}
