import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddStudentDetailsComponent } from './add-student-details/add-student-details.component';
import { AddLectureDetailsComponent } from './add-lecture-details/add-lecture-details.component';
import { AddEventDetailsComponent } from './add-event-details/add-event-details.component';
import { AddHolidayDetailsComponent } from './add-holiday-details/add-holiday-details.component';
import { ViewLectureDetailsComponent } from './view-lecture-details/view-lecture-details.component';
import { ViewEventDetailsComponent } from './view-event-details/view-event-details.component';
import { ViewHolidayDetailsComponent } from './view-holiday-details/view-holiday-details.component';
 import { ViewStudentDetailsComponent } from './view-student-details/view-student-details.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
//import { AdminloginService } from './adminlogin.service';
const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'add-student-details', component: AddStudentDetailsComponent },
  { path: 'add-lecture-details', component: AddLectureDetailsComponent },
  { path: 'add-event-details', component: AddEventDetailsComponent },
  { path: 'add-holiday-details', component: AddHolidayDetailsComponent },
    { path: 'view-student-details', component: ViewStudentDetailsComponent },
  { path: 'view-lecture-details', component: ViewLectureDetailsComponent },
  { path: 'view-event-details', component: ViewEventDetailsComponent },
  { path: 'view-holiday-details', component: ViewHolidayDetailsComponent },
  { path: 'login', component: LoginComponent },
  { path: 'logout', component: LogoutComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
