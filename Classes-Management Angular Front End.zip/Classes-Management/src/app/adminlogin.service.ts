import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AdminloginService {
  router: any;
  constructor() { }

  isUserLoggedIn()
  {
    let user = sessionStorage.getItem('uname');
    //console.log(!(user === null));
    return !(user === null);
  }

  // isUser()
  // {
  //   let loginType =sessionStorage.getItem('loginType');
  //   return (loginType=='student');
  // }

  logout()
  {
    sessionStorage.removeItem('uname');
   
  }
}
