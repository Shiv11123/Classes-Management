import { Component, OnInit } from '@angular/core';
import { Event } from '../event';  
import{EventService} from '../event.service';
import { Observable,Subject } from "rxjs";  
import {FormControl,FormGroup,Validators} from '@angular/forms';  
import { AdminloginService } from '../adminlogin.service';

@Component({
  selector: 'app-view-event-details',
  templateUrl: './view-event-details.component.html',
  styleUrls: ['./view-event-details.component.css']
})
export class ViewEventDetailsComponent implements OnInit {

  constructor(private eventservice:EventService, public authservice:AdminloginService) { }

  eventsArray: any[] = [];  
  events: Observable<Event[]>; 
  event:Event=new Event();

  deleteMessage=false;  
  eventlist:any;  
  isupdated = false;

  searchText;

  ngOnInit(): void {

    console.log("inside oninit");
    this.eventservice.getEventList().subscribe(data =>{  
      this.events =data;
      console.log(data);
    }) 

  }

  deleteEvent(event_id: number) {  
    this.eventservice.deleteEvent(event_id)  
      .subscribe(  
        data => {  
          console.log(data);  
          this.deleteMessage=true;  
          this.eventservice.getEventList().subscribe(data =>{  
            this.events =data  
            })  
        },  
        error => console.log(error));  
  }  
  
  updateEvent(event_id: number){  
    this.eventservice.getEvent(event_id)  
      .subscribe(  
        data => {  
          this.eventlist=Array.of(data)          
        },  
        error => console.log(error));  
  }  
  
  eventupdateform=new FormGroup({  
    
    event_id:new FormControl(),  
    event_name:new FormControl(),  
    event_description:new FormControl(),  
    event_date:new FormControl(),
    event_start_time:new FormControl(),  
    event_end_time:new FormControl()
  });  
  
  updateEve(updeve){  
    this.event=new Event();     
    this.event.event_id=this.EventId.value; 
    this.event.event_name=this.EventName.value;  
    this.event.event_description=this.EventDescription.value;  
    this.event.event_date=this.EventDate.value;
    this.event.event_start_time=this.EventStartTime.value;
    this.event.event_end_time=this.EventEndTime.value;  
  
   console.log(this.EventName.value);  
     
  
   this.eventservice.updateEvent(this.event.event_id,this.event).subscribe(  
    data => {       
      this.isupdated=true;  
      this.eventservice.getEventList().subscribe(data =>{  
        this.events =data  
        })  
    },  
    error => console.log(error));  
  }
  
  get EventId(){  
    return this.eventupdateform.get('event_id');  
  }  
  

  get EventName(){  
    return this.eventupdateform.get('event_name');  
  }  
  
  get EventDescription(){  
    return this.eventupdateform.get('event_description');  
  }  
  
  get EventDate(){  
    return this.eventupdateform.get('event_date');  
  }  
  
  get EventStartTime(){  
    return this.eventupdateform.get('event_start_time');  
  } 
  
  get EventEndTime(){  
    return this.eventupdateform.get('event_end_time');  
  } 
  
  changeisUpdate(){  
    this.isupdated=false;  
  } 
}
