import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';  
import { Observable } from 'rxjs';  

@Injectable({
  providedIn: 'root'
})
export class  LectureService {
  postLecture(lecture_id: number) {
    throw new Error("Method not implemented.");
    }

    private baseUrlSave = 'http://localhost:8080/Classes-Management-Spring/savelecture/';
    private baseUrlGet = 'http://localhost:8080/Classes-Management-Spring/getlectures/';
    private delUrl = 'http://localhost:8080/Classes-Management-Spring/lecture-del/';
    private getUrl = 'http://localhost:8080/Classes-Management-Spring/findlecture/';
    private updUrl = 'http://localhost:8080/Classes-Management-Spring/lecture-update/';
    
  constructor(private http:HttpClient) { }

  createLecture(lecture: object): Observable<object> {
    console.log(this.http.get(`${this.baseUrlSave}`));
    return this.http.post(`${this.baseUrlSave}`, lecture);
    }

    getLectureList(): Observable<any> {  
      return this.http.get(`${this.baseUrlGet}`);  
    }  
   
    
    deleteLecture(lecture_id: number): Observable<any> {  
      return this.http.delete(`${this.delUrl}${lecture_id}`, { responseType: 'text' });  
    }  
    
    getLecture(lecture_id: number): Observable<Object> {  
      return this.http.get(`${this.getUrl}${lecture_id}`);  
    }  
    
    updateLecture(lecture_id: number, value: any): Observable<Object> {  
      return this.http.put(`${this.updUrl}${lecture_id}`, value);  
    }  
}
