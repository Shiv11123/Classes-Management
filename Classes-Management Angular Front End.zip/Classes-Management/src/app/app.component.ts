import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { NzDropDownModule,NzPlacementType  } from 'ng-zorro-antd/dropdown';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { AdminloginService } from './adminlogin.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor( public authservice : AdminloginService){}

  title = 'Classes-Management';
  NzGridModule :NzGridModule;
  listOfPosition: NzPlacementType[] = ['bottomLeft'];
  studentsaveform: FormGroup;
  lecturesaveform: FormGroup;
  eventsaveform: FormGroup;
  holidaysaveform: FormGroup;
  lectureupdateform: FormGroup;
  loginForm: FormGroup;
}
