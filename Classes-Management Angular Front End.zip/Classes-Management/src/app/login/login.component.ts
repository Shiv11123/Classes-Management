import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {Router} from '@angular/router';
import { Login } from '../login';
import { LoginService } from '../login.service';
import { AdminloginService } from '../adminlogin.service';
import { NzRadioModule } from 'ng-zorro-antd/radio';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  
})
export class LoginComponent implements OnInit {
   loginForm!: FormGroup;
   invalidLogin = false;
   admindetails:Login[];
   uname = ''
   password = ''
   login_type = 'admin';

   
  ngOnInit(): void {
    this.loginForm = this.fb.group({
      uname: [null, [Validators.required]],
      password: [null, [Validators.required]],
      remember: [true]
    });
    this.loginservice.getLoginDetails().subscribe(data =>{  
      this.admindetails =data;
      console.log(JSON.stringify(data));
      //console.log("api list ::: "+JSON.stringify(this.admindetails[0].uname));
  })
}

  submitForm(): void {
    for (const i in this.loginForm.controls) {
      this.loginForm.controls[i].markAsDirty();
      this.loginForm.controls[i].updateValueAndValidity();
    }
  }

  constructor(private fb: FormBuilder, private router: Router,private loginservice:LoginService,public authservice:AdminloginService) { }
  //  redirect() {
  //    this.router.navigate(['/view-lecture-details/']);
  //  }

  authenticate(uname,password,login_type)
  {
    for(var i=0;i<=this.admindetails.length;i++)
    {
      if(uname == this.admindetails[i].uname && password == this.admindetails[i].password)
      {
        sessionStorage.setItem('uname',uname);
        sessionStorage.setItem('loginType',login_type);
        return true;
      }
      
       }

  }

  checkLogin()
  {
    if(this.authenticate(this.uname,this.password,this.login_type))
    {
      
      this.router.navigate(['add-student-details'])
      
      this.invalidLogin=false

    }
    else
    
     this.invalidLogin=true
     
  }

  

}


