import { Demo } from './demo';

describe('Demo', () => {
  it('should create an instance', () => {
    expect(new Demo()).toBeTruthy();
  });
});
