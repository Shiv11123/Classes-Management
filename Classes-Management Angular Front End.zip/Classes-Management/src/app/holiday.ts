export class Holiday {
    holiday_id:number;
    holiday_reason:String;
    holiday_date:Date;
}
