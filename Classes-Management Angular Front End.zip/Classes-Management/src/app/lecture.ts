export class Lecture {
    lecture_id:number;
    lecture_name:String;
    faculty_name:String;
    lecture_date:Date;
    lecture_start_time:String;
    lecture_end_time:String;
}
