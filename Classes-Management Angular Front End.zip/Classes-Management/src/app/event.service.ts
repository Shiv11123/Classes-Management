import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';  
import { Observable } from 'rxjs';  

@Injectable({
  providedIn: 'root'
})
export class EventService {
  postEvent(event_id: number) {
    throw new Error("Method not implemented.");
  }
  private baseUrlSave = 'http://localhost:8080/Classes-Management-Spring/saveevent/';
  private baseUrlGet = 'http://localhost:8080/Classes-Management-Spring/getevents/';
  private delurl = 'http://localhost:8080/Classes-Management-Spring/event-del/';
  private updurl = 'http://localhost:8080/Classes-Management-Spring/event-update/';
  private geturl = 'http://localhost:8080/Classes-Management-Spring/findevent/';


  constructor(private http:HttpClient) { }
  createEvent(event: object): Observable<object> {
    console.log(this.http.get(`${this.baseUrlSave}`));
    return this.http.post(`${this.baseUrlSave}`, event);
    }

    getEventList(): Observable<any> {  
      return this.http.get(`${this.baseUrlGet}`);  
    }  
   
    deleteEvent(event_id: number): Observable<any> {  
      return this.http.delete(`${this.delurl}${event_id}`, { responseType: 'text' });  
    }  
    
    getEvent(event_id: number): Observable<Object> {  
      return this.http.get(`${this.geturl}${event_id}`);  
    }  
    
    updateEvent(event_id: number, value: any): Observable<Object> {  
      return this.http.put(`${this.updurl}${event_id}`, value);  
    }  
}


