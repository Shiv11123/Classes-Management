export class Student {
    student_id:number;
    full_name:String;
    email_id:String;
    contact_no:number;
    address:String;
    course_name:String;
    course_duration_from:Date;
    course_duration_to:Date;
    total_fees:number;
    paid_fees:number;
    balance_fees:number;
}
