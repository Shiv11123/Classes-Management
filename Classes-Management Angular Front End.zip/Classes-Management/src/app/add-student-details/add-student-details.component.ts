import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import getISOWeek from 'date-fns/getISOWeek';
import { en_US, NzI18nService, zh_CN } from 'ng-zorro-antd/i18n';
import { StudentService } from '../student.service';
import { Student } from '../student';
import { Router } from '@angular/router';
@Component({
  selector: 'app-add-student-details',
  templateUrl: './add-student-details.component.html',
  styleUrls: ['./add-student-details.component.css']
})
export class AddStudentDetailsComponent implements OnInit {
  start_date = null;
  end_date = null;
  dateRange = [];
  isEnglish = false;

  studentsaveform!: FormGroup;
  controlArray: Array<{ index: number; show: boolean }> = [];
  isCollapse = true;

  constructor(private fb: FormBuilder, private i18n: NzI18nService, private studentservice: StudentService, private router: Router) { }
   redirect3() {
     
     this.saveStudent()
     this.router.navigate(['/view-student-details/']);
   }

  student: Student = new Student();
  types: Student[];
  submitted = false;



  ngOnInit(): void {
    this.studentsaveform = this.fb.group({
      student_id: new FormControl(''),
      full_name: new FormControl('', [Validators.required, Validators.minLength(3)]),
      email_id: new FormControl('', [Validators.required, Validators.minLength(5)]),
      contact_no: new FormControl('', [Validators.required]),
      address: new FormControl('', [Validators.required]),
      course_name: new FormControl('', [Validators.required]),
      course_duration_from: new FormControl('', [Validators.required]),
      course_duration_to: new FormControl('', [Validators.required]),
      total_fees: new FormControl('', [Validators.required]),
      paid_fees: new FormControl('', [Validators.required]),
      balance_fees: new FormControl('', [Validators.required]),
    });

    for (let i = 0; i < 10; i++) {
      this.controlArray.push({ index: i, show: i < 6 });
      this.studentsaveform.addControl(`field${i}`, new FormControl());
      this.submitted = false;
    }
  }

  toggleCollapse(): void {
    this.isCollapse = !this.isCollapse;
    this.controlArray.forEach((c, index) => {
      c.show = this.isCollapse ? index < 6 : true;
    });
  }

  onChange(result: Date): void {
    console.log('onChange: ', result);
  }
  getWeek(result: Date): void {
    console.log('week: ', getISOWeek(result));
  }

  changeLanguage(): void {
    this.i18n.setLocale(this.isEnglish ? zh_CN : en_US);
    this.isEnglish = !this.isEnglish;
  }

  saveStudent() {
    this.student = new Student();
    this.student.student_id = this.StudentId.value;
    this.student.full_name = this.FullName.value;
    this.student.email_id = this.EmailId.value;
    this.student.contact_no = this.ContactNo.value;
    this.student.address = this.Address.value;
    this.student.course_name = this.Address.value;
    this.student.course_duration_from = this.CourseDurationFrom.value;
    this.student.course_duration_to = this.CourseDurationTo.value;
    this.student.total_fees = this.TotalFees.value;
    this.student.paid_fees = this.PaidFees.value;
    this.student.balance_fees = this.BalanceFees.value;
    this.submitted = true;
    this.save();
   

  }

  save() {
    console.log(JSON.stringify(this.student))
    this.studentservice.createStudent(this.student)
      .subscribe(data => console.log(data), error => console.log(error));
    this.student = new Student();
  }


  get StudentId() {
    return this.studentsaveform.get("student_id");
  }

  get FullName() {
    return this.studentsaveform.get("full_name");
  }

  get EmailId() {
    return this.studentsaveform.get("email_id");
  }

  get ContactNo() {
    return this.studentsaveform.get("contact_no");
  }

  get Address() {
    return this.studentsaveform.get("address");
  }

  get CourseDurationFrom() {
    return this.studentsaveform.get("course_duration_from");
  }

  get CourseDurationTo() {
    return this.studentsaveform.get("course_duration_to");
  }

  get TotalFees() {
    return this.studentsaveform.get("total_fees");
  }

  get PaidFees() {
    return this.studentsaveform.get("paid_fees");
  }

  get BalanceFees() {
    return this.studentsaveform.get("balance_fees");
  }


  addStudentForm() {
    this.submitted = false;
    this.studentsaveform.reset();
  }

}
