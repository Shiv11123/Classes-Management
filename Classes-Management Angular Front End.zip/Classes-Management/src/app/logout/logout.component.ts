import { Component, OnInit } from '@angular/core';
import { AdminloginService } from '../adminlogin.service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {
  router: any;

  constructor(private authService:AdminloginService) { }

  ngOnInit(): void {
    this.authService.logout();
    
    this.router.navigate(['login'])
  }

}
