import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import getISOWeek from 'date-fns/getISOWeek';
import { en_US, NzI18nService, zh_CN } from 'ng-zorro-antd/i18n';
import { EventService } from '../event.service';
import { Event } from '../event';
import {Router} from '@angular/router';
import * as moment from 'moment';


@Component({
  selector: 'app-add-event-details',
  templateUrl: './add-event-details.component.html',
  styleUrls: ['./add-event-details.component.css']
})
export class AddEventDetailsComponent implements OnInit {

  dateFormat="yyyy/MM/dd";
  date = null;
  dateRange = [];
  isEnglish = false;

  time: Date | null = null;
  time1: Date | null = null;

  eventsaveform!: FormGroup;
  controlArray: Array<{ index: number; show: boolean }> = [];
  isCollapse = true;
  
  constructor(private fb: FormBuilder,private i18n: NzI18nService,private eventservice:EventService, private router:Router) { }
   redirect2() {
     this.router.navigate(['/view-event-details/']);
   }

  event : Event = new Event();
  types:Event[];
  submitted=false;

  onChange(result: Date): void {
    console.log('onChange: ', result);
  }
  ngOnInit(): void {
    this.eventsaveform = this.fb.group({
      event_id:new FormControl(''),
      event_name:new FormControl('' , [Validators.required , Validators.minLength(3) ] ),
      event_description:new FormControl('' , [Validators.required , Validators.minLength(3) ] ),
      event_date:new FormControl('' , [Validators.required ] ),
      event_start_time:new FormControl('' , [Validators.required ] ),
      event_end_time:new FormControl('' , [Validators.required ] ),
      });
  
      for (let i = 0; i < 10; i++) {
        this.controlArray.push({ index: i, show: i < 6 });
        this.eventsaveform.addControl(`field${i}`, new FormControl());
        this.submitted=false;
      }
  }

  saveEvent(saveEvent){
    this.event=new Event();
    this.event.event_id=this.EventId.value;
    this.event.event_name=this.EventName.value;
    this.event.event_description=this.EventDescription.value;
    this.event.event_date=this.EventDate.value;
    this.event.event_start_time=moment(this.EventStartTime.value).format("hh:mm A");
    this.event.event_end_time=moment(this.EventEndTime.value).format("hh:mm A");
    this.save();
    }

    save() {  
      console.log(JSON.stringify(this.event))
      this.eventservice.createEvent(this.event)  
        .subscribe(data => console.log(data), error => console.log(error));  
      this.event = new Event();  
    }  
    

      get EventId(){
          return this.eventsaveform.get("event_id");
      }

      get EventName(){
        return this.eventsaveform.get("event_name");
      }

      get EventDescription(){
        return this.eventsaveform.get("event_description");
      }

      get EventDate(){
        return this.eventsaveform.get("event_date");
      }

      get EventStartTime(){
        return this.eventsaveform.get("event_start_time");
      }

      get EventEndTime(){
        return this.eventsaveform.get("event_end_time");
      }


      addEventForm(){
        this.submitted=false;
        this.eventsaveform.reset();
      }



}
