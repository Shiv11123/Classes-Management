import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';  
import { Observable } from 'rxjs';  

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  postStudent(student_id: number) {
    throw new Error("Method not implemented.");
    }

    private baseUrlSave = 'http://localhost:8080/Classes-Management-Spring/savestudent/';
    private baseUrlGet = 'http://localhost:8080/Classes-Management-Spring/getstudents/';
    private delUrl = 'http://localhost:8080/Classes-Management-Spring/student-del/';
    private getUrl = 'http://localhost:8080/Classes-Management-Spring/findstudent/';
    private updUrl = 'http://localhost:8080/Classes-Management-Spring/student-update/';

  constructor(private http:HttpClient) { }
  createStudent(student: object): Observable<object> {
    console.log(this.http.get(`${this.baseUrlSave}`));
    return this.http.post(`${this.baseUrlSave}`, student);
    }

    getStudentList(): Observable<any> {  
      return this.http.get(`${this.baseUrlGet}`);  
    }  
   
    
    deleteStudent(student_id: number): Observable<any> {  
      return this.http.delete(`${this.delUrl}${student_id}`, { responseType: 'text' });  
    }  
    
    getStudent(student_id: number): Observable<Object> {  
      return this.http.get(`${this.getUrl}${student_id}`);  
    }  
    
    updateStudent(student_id: number, value: any): Observable<Object> {  
      return this.http.put(`${this.updUrl}${student_id}`, value);  
    }  
}
