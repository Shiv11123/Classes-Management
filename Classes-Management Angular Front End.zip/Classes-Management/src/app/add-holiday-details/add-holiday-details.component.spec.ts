import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddHolidayDetailsComponent } from './add-holiday-details.component';

describe('AddHolidayDetailsComponent', () => {
  let component: AddHolidayDetailsComponent;
  let fixture: ComponentFixture<AddHolidayDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddHolidayDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddHolidayDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
