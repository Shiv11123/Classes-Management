import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import getISOWeek from 'date-fns/getISOWeek';
import { en_US, NzI18nService, zh_CN } from 'ng-zorro-antd/i18n';
import { HolidayService } from '../holiday.service';
import { Holiday } from '../holiday';

@Component({
  selector: 'app-add-holiday-details',
  templateUrl: './add-holiday-details.component.html',
  styleUrls: ['./add-holiday-details.component.css']
})
export class AddHolidayDetailsComponent implements OnInit {
  dateFormat="yyyy/MM/dd";
  date = null;
  dateRange = [];
  isEnglish = false;
  
  holidaysaveform!: FormGroup;
  controlArray: Array<{ index: number; show: boolean }> = [];
  isCollapse = true;
  router: any;

  constructor(private fb: FormBuilder,private i18n: NzI18nService,private holidayservice:HolidayService) { }
  holiday : Holiday = new Holiday();
  types:Holiday[];
  submitted=false;

  redirect2() {
    this.router.navigate(['/view-holiday-details/']);
  }

  onChange(result: Date): void {
    console.log('onChange: ', result);
  }

  ngOnInit(): void {
    this.holidaysaveform = this.fb.group({
      holiday_id:new FormControl('' , [Validators.required ]),
      holiday_reason:new FormControl('' , [Validators.required , Validators.minLength(3) ] ),
      holiday_date:new FormControl('' , [Validators.required ] ),
      });
  
      for (let i = 0; i < 10; i++) {
        this.controlArray.push({ index: i, show: i < 6 });
        this.holidaysaveform.addControl(`field${i}`, new FormControl());
        this.submitted=false;
      }
  }

  saveHoliday(saveHoliday){
    this.holiday=new Holiday();
    this.holiday.holiday_id=this.HolidayId.value;
    this.holiday.holiday_reason=this.HolidayReason.value;
    this.holiday.holiday_date=this.HolidayDate.value;
    this.submitted = true;
    this.save();
    }

    save() {  
      console.log(JSON.stringify(this.holiday))
      this.holidayservice.createHoliday(this.holiday)  
        .subscribe(data => console.log(data), error => console.log(error));  
      this.holiday = new Holiday();  
    }  
    

      get HolidayId(){
          return this.holidaysaveform.get("holiday_id");
      }

      get HolidayReason(){
        return this.holidaysaveform.get("holiday_reason");
      }

      get HolidayDate(){
        return this.holidaysaveform.get("holiday_date");
      }


      addHolidayForm(){
        this.submitted=false;
        this.holidaysaveform.reset();
      }



}
