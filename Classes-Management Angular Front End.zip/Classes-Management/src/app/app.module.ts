import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NgZorroAntdModule, } from 'ng-zorro-antd';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzSelectModule } from 'ng-zorro-antd/select';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddLectureDetailsComponent } from './add-lecture-details/add-lecture-details.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NZ_I18N } from 'ng-zorro-antd/i18n';
import { en_US } from 'ng-zorro-antd/i18n';
import { registerLocaleData } from '@angular/common';
import en from '@angular/common/locales/en';
import { AddStudentDetailsComponent } from './add-student-details/add-student-details.component';
import { AddEventDetailsComponent } from './add-event-details/add-event-details.component';
import { AddHolidayDetailsComponent } from './add-holiday-details/add-holiday-details.component';
//import { AddFacultyDetailsComponent } from './add-faculty-details/add-faculty-details.component';
//import { AddBooksDetailsComponent } from './add-books-details/add-books-details.component';
import { ViewLectureDetailsComponent } from './view-lecture-details/view-lecture-details.component';
import { ViewEventDetailsComponent } from './view-event-details/view-event-details.component';
import { ViewHolidayDetailsComponent } from './view-holiday-details/view-holiday-details.component';
import { LoginComponent } from './login/login.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
 import { ViewStudentDetailsComponent } from './view-student-details/view-student-details.component';

import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { LogoutComponent } from './logout/logout.component';
//import { AdminloginService } from './adminlogin.service';

registerLocaleData(en);

@NgModule({
  declarations: [
    AppComponent,
    AddStudentDetailsComponent,
    AddLectureDetailsComponent,
    AddEventDetailsComponent,
    AddHolidayDetailsComponent,
    //AddFacultyDetailsComponent,
    //AddBooksDetailsComponent,
    ViewLectureDetailsComponent,
    ViewEventDetailsComponent,
    ViewHolidayDetailsComponent,
    LoginComponent,
     ViewStudentDetailsComponent,
    LogoutComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    NzFormModule,
    NgZorroAntdModule,
    NzTableModule,
    NzSelectModule,
    Ng2SearchPipeModule,
    NgbModule
  ],
  providers: [{ provide: NZ_I18N, useValue: en_US }],
  bootstrap: [AppComponent]
})
export class AppModule { }
