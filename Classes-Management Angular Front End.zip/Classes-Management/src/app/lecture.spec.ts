import { Lecture } from './lecture';

describe('Lecture', () => {
  it('should create an instance', () => {
    expect(new Lecture()).toBeTruthy();
  });
});
