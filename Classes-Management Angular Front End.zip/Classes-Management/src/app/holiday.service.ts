import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';  
import { Observable } from 'rxjs';  


@Injectable({
  providedIn: 'root'
})
export class HolidayService {
  postHoliday(holiday_id: number) {
    throw new Error("Method not implemented.");
  }
  private baseUrlSave = 'http://localhost:8080/Classes-Management-Spring/saveholiday/';
  private baseUrlGet = 'http://localhost:8080/Classes-Management-Spring/getholidays/';
  private delUrl = 'http://localhost:8080/Classes-Management-Spring/holiday-del/';
  private getUrl = 'http://localhost:8080/Classes-Management-Spring/findholiday/';
  private updUrl = 'http://localhost:8080/Classes-Management-Spring/holiday-update/';

  constructor(private http:HttpClient) { }
  createHoliday(holiday: object): Observable<object> {
    console.log(this.http.get(`${this.baseUrlSave}`));
    return this.http.post(`${this.baseUrlSave}`, holiday);
    }

    getHolidayList(): Observable<any> {  
      console.log(this.http.get(`${this.baseUrlGet}`))
      return this.http.get(`${this.baseUrlGet}`);  
    }  
   
    deleteHoliday(id: number): Observable<any> {  
      return this.http.delete(`${this.delUrl}${id}`, { responseType: 'text' });  
    }  
    
    getHoliday(id: number): Observable<Object> {  
      return this.http.get(`${this.getUrl}${id}`);  
    }  
    
    updateHoliday(id: number, value: any): Observable<Object> {  
      return this.http.put(`${this.updUrl}${id}`, value);  
    }  

}
