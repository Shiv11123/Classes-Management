import { Component, OnInit } from '@angular/core';
import { Lecture } from '../lecture';  
import{LectureService} from '../lecture.service';
import { Observable,Subject } from "rxjs";  
import {FormControl,FormGroup,Validators} from '@angular/forms';  
import { AdminloginService } from '../adminlogin.service';


@Component({
  selector: 'app-view-lecture-details',
  templateUrl: './view-lecture-details.component.html',
  styleUrls: ['./view-lecture-details.component.css']
})
export class ViewLectureDetailsComponent implements OnInit {
  

  constructor(private lectureservice:LectureService, public authservice:AdminloginService) { }

  lecturesArray: any[] = [];  
  lectures: Observable<Lecture[]>; 
  lecture:Lecture=new Lecture();

  deleteMessage=false;  
  lecturelist:any;  
  isupdated = false;

  searchText;

  ngOnInit(): void {
    console.log("inside oninit");
    this.lectureservice.getLectureList().subscribe(data =>{  
      this.lectures =data;
      console.log(data);
    }) 
}

deleteLecture(lecture_id: number) {  
  this.lectureservice.deleteLecture(lecture_id)  
    .subscribe(  
      data => {  
        console.log(data);  
        this.deleteMessage=true;  
        this.lectureservice.getLectureList().subscribe(data =>{  
          this.lectures =data  
          })  
      },  
      error => console.log(error));  
} 
updateLecture(lecture_id: number){  
  this.lectureservice.getLecture(lecture_id)  
    .subscribe(  
      data => {  
        console.log(data)
        this.lecturelist=Array.of(data)         
            
      },  
      error => console.log(error));  
}  

lectureupdateform=new FormGroup({  
  
  lecture_id:new FormControl(),  
  lecture_name:new FormControl(),  
  faculty_name:new FormControl(),  
  lecture_date:new FormControl(),
  lecture_start_time:new FormControl(),  
  lecture_end_time:new FormControl()
});  

updateLec(updlec){  
  this.lecture=new Lecture();     
  this.lecture.lecture_id=this.LectureId.value;  
  this.lecture.lecture_name=this.LectureName.value;  
  this.lecture.faculty_name=this.FacultyName.value;  
  this.lecture.lecture_date=this.LectureDate.value;
  this.lecture.lecture_start_time=this.LectureStartTime.value;
  this.lecture.lecture_end_time=this.LectureEndTime.value;  

 console.log(this.LectureName.value);  
   

 this.lectureservice.updateLecture(this.lecture.lecture_id,this.lecture).subscribe(  
  data => {       
    this.isupdated=true;  
    this.lectureservice.getLectureList().subscribe(data =>{  
      this.lectures =data  
      })  
  },  
  error => console.log(error));  
}  


get LectureId(){  
  return this.lectureupdateform.get('lecture_id');  
} 

get LectureName(){  
  return this.lectureupdateform.get('lecture_name');  
}  

get FacultyName(){  
  return this.lectureupdateform.get('faculty_name');  
}  

get LectureDate(){  
  return this.lectureupdateform.get('lecture_date');  
}  

get LectureStartTime(){  
  return this.lectureupdateform.get('lecture_start_time');  
} 

get LectureEndTime(){  
  return this.lectureupdateform.get('lecture_end_time');  
} 

changeisUpdate(){  
  this.isupdated=false;  
} 

}
