import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewLectureDetailsComponent } from './view-lecture-details.component';

describe('ViewLectureDetailsComponent', () => {
  let component: ViewLectureDetailsComponent;
  let fixture: ComponentFixture<ViewLectureDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewLectureDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewLectureDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
