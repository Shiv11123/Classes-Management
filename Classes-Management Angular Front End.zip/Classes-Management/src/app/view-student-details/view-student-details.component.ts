import { Component, OnInit } from '@angular/core';
import { Student } from '../student';
import { StudentService } from '../student.service';
import { Observable, Subject } from "rxjs";
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AdminloginService } from '../adminlogin.service';

@Component({
  selector: 'app-view-student-details',
  templateUrl: './view-student-details.component.html',
  styleUrls: ['./view-student-details.component.css']
})
export class ViewStudentDetailsComponent implements OnInit {

  constructor(private studentservice: StudentService, public authservice:AdminloginService) { }
  studentsArray: any[] = [];
  students: Observable<Student[]>;
  student: Student = new Student();

  deleteMessage = false;
  studentlist: any;
  isupdated = false;

  searchText;

  ngOnInit(): void {
    console.log("inside oninit");
    this.studentservice.getStudentList().subscribe(data => {
      this.students = data;
      console.log(data);
    })
  }

  deleteStudent(student_id: number) {
    this.studentservice.deleteStudent(student_id)
      .subscribe(
        data => {
          console.log(data);
          this.deleteMessage = true;
          this.studentservice.getStudentList().subscribe(data => {
            this.students = data
          })
        },
        error => console.log(error));
  }

  updateStudent(student_id: number) {
    this.studentservice.getStudent(student_id)
      .subscribe(
        data => {
          console.log(data)
          this.studentlist = Array.of(data)
        },
        error => console.log(error));
  }

  studentupdateform = new FormGroup({

    student_id: new FormControl(),
    full_name: new FormControl(),
    email_id: new FormControl(),
    contact_no: new FormControl(),
    address: new FormControl(),
    course_name: new FormControl(),
    course_duration_from: new FormControl(),
    course_duration_to: new FormControl(),
    total_fees: new FormControl(),
    paid_fees: new FormControl(),
    balance_fees: new FormControl()
  });

  updateStu(updstu) {
    this.student = new Student();
    this.student.student_id = this.StudentId.value;
    this.student.full_name = this.FullName.value;
    this.student.email_id = this.EmailId.value;
    this.student.contact_no = this.ContactNo.value;
    this.student.address = this.Address.value;
    this.student.course_name = this.CourseName.value;
    this.student.course_duration_from = this.CourseDurationFrom.value;
    this.student.course_duration_to = this.CourseDurationTo.value;
    this.student.total_fees = this.TotalFees.value;
    this.student.paid_fees = this.PaidFees.value;
    this.student.balance_fees = this.BalanceFees.value;


    //console.log(this.FullName.value);  


    this.studentservice.updateStudent(this.student.student_id, this.student).subscribe(
      data => {
        this.isupdated = true;
        this.studentservice.getStudentList().subscribe(data => {
          this.students = data
        })
      },
      error => console.log(error));
  }

  printComponent(MyDiv) {
    let printContents = document.getElementById(MyDiv).innerHTML;
    let originalContents = document.body.innerHTML;

    // window.document.write(`<html><head><link rel="stylesheet" 
    // type="text/css" href="test.component.css" /></head><body>`)
    document.body.innerHTML = printContents;

    window.print();

    document.body.innerHTML = originalContents;
    window.location.reload();

  }

  get StudentId() {
    return this.studentupdateform.get('student_id');
  }

  get FullName() {
    return this.studentupdateform.get('full_name');
  }

  get EmailId() {
    return this.studentupdateform.get('email_id');
  }

  get ContactNo() {
    return this.studentupdateform.get('contact_no');
  }

  get Address() {
    return this.studentupdateform.get('address');
  }

  get CourseName() {
    return this.studentupdateform.get('course_name');
  }

  get CourseDurationFrom() {
    return this.studentupdateform.get('course_duration_from');
  }

  get CourseDurationTo() {
    return this.studentupdateform.get('course_duration_to');
  }

  get TotalFees() {
    return this.studentupdateform.get('total_fees');
  }

  get PaidFees() {
    return this.studentupdateform.get('paid_fees');
  }

  get BalanceFees() {
    return this.studentupdateform.get('balance_fees');
  }

  changeisUpdate() {
    this.isupdated = false;
  }

}
