package com.classes.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {

	@RequestMapping("/home")
	public String Print(ModelMap model)
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("display");
		System.out.println("inside the HomeController");
		model.addAttribute("message", "The Classes Application");
		return "display";
	}
}

