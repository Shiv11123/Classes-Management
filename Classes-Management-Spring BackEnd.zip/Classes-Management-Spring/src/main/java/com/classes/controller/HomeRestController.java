package com.classes.controller;
import java.util.List;

import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.classes.model.Lecture;
import com.classes.model.Login;
import com.classes.model.Student;
import com.classes.model.Event;
import com.classes.model.Holiday;
import com.classes.service.LectureService;
import com.classes.service.LoginService;
//import com.classes.service.LoginService;
import com.classes.service.EventService;
import com.classes.service.HolidayService;
import com.classes.service.StudentService;

@CrossOrigin("*")
@RestController
public class HomeRestController {
	
	@Autowired 
	LectureService lectureService;
	
	@Autowired 
	EventService eventService;
	
	@Autowired 
	HolidayService holidayService;
	
	@Autowired 
	StudentService studentService;
	
	@Autowired
	LoginService loginservice;
	

	
	//------------ save lecture ------------//
	
		@RequestMapping(value="/savelecture/",method=RequestMethod.POST)
		public ResponseEntity<Void> createLecture(@RequestBody Lecture lecture,UriComponentsBuilder ucBuilder)
		{
			lectureService.saveLecture(lecture);
			
			return new ResponseEntity<>(HttpStatus.CREATED);
		}
		

		//------------- get all lectures -------------//
		
		@RequestMapping(value = "/getlectures/",method = RequestMethod.GET)
		public ResponseEntity<List<Lecture>> listalllectures()
		{
			List<Lecture> lectures=lectureService.findalllectures();
			
			if(lectures.isEmpty())
			{
				return new ResponseEntity<List<Lecture>>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<List<Lecture>>(lectures,HttpStatus.OK);
		}
		
	//----------------delete lecture--------------//
		
		@RequestMapping(value = "/lecture-del/{lecture_id}", method = RequestMethod.DELETE)
		public ResponseEntity<Lecture> deleteLecture(@PathVariable("lecture_id") long lecture_id) {
			System.out.println("Fetching & Deleting lecture with id " + lecture_id);

			Lecture lecture = lectureService.findById(lecture_id);
			if (lecture == null) {
				System.out.println("Unable to delete. User with id " + lecture_id + " not found");
				return new ResponseEntity<Lecture>(HttpStatus.NOT_FOUND);
			}

			lectureService.deleteLectureById(lecture_id);
			return new ResponseEntity<Lecture>(HttpStatus.NO_CONTENT);
		}
		
	
		//-----------find lecture by id --------//

				@RequestMapping(value = "/findlecture/{lecture_id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
				public ResponseEntity<Lecture> getLecture(@PathVariable("lecture_id") long lecture_id) {
					System.out.println("Fetching lecture with id " + lecture_id);
					Lecture lecture = lectureService.findById(lecture_id);
					return new ResponseEntity<Lecture>(lecture, HttpStatus.OK);
				}
		
		
		//-----------update lecture----------//
		
		@RequestMapping(value = "/lecture-update/{lecture_id}", method = RequestMethod.PUT)
		public ResponseEntity<Lecture> updateLecture(@PathVariable("lecture_id") long lecture_id, @RequestBody Lecture lecture) {
			System.out.println("Updating Lecture " + lecture_id);
			
			Lecture currentLecture = lectureService.findById(lecture_id);
			
			if (currentLecture==null) {
				System.out.println("Lecture with id " + lecture_id + " not found");
				return new ResponseEntity<Lecture>(HttpStatus.NOT_FOUND);
			}

			currentLecture.setLecture_name(lecture.getLecture_name());
			currentLecture.setFaculty_name(lecture.getFaculty_name());
			currentLecture.setLecture_date(lecture.getLecture_date());
			currentLecture.setLecture_start_time(lecture.getLecture_start_time());
			currentLecture.setLecture_end_time(lecture.getLecture_end_time());

			lectureService.updateLecture(currentLecture);
			return new ResponseEntity<Lecture>(currentLecture, HttpStatus.OK);
		}


		//------------ save event ------------//
		
		@RequestMapping(value="/saveevent/",method=RequestMethod.POST)
		public ResponseEntity<Void> createEvent(@RequestBody Event event,UriComponentsBuilder ucBuilder)
		{
			eventService.saveEvent(event);
			
			return new ResponseEntity<>(HttpStatus.CREATED);
			
		}
		

		//------------- get all events -------------//
		
		@RequestMapping(value = "/getevents/",method = RequestMethod.GET)
		public ResponseEntity<List<Event>> listallevents()
		{
			List<Event> events=eventService.findallevents();
			
			if(events.isEmpty())
			{
				return new ResponseEntity<List<Event>>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<List<Event>>(events,HttpStatus.OK);
		}
		

		//----------------delete event--------------//
		
		@RequestMapping(value = "/event-del/{event_id}", method = RequestMethod.DELETE)
		public ResponseEntity<Event> deleteEvent(@PathVariable("event_id") long event_id) {
			System.out.println("Fetching & Deleting event with id " + event_id);

			Event event = eventService.findById(event_id);
			if (event == null) {
				System.out.println("Unable to delete. User with id " + event_id + " not found");
				return new ResponseEntity<Event>(HttpStatus.NOT_FOUND);
			}

			eventService.deleteEventById(event_id);
			return new ResponseEntity<Event>(HttpStatus.NO_CONTENT);
		}
		
		
		//---------find event by id ------

		@RequestMapping(value = "/findevent/{event_id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
		public ResponseEntity<Event> getEvent(@PathVariable("event_id") long event_id) {
			System.out.println("Fetching event with id " + event_id);
			Event event = eventService.findById(event_id);
			return new ResponseEntity<Event>(event, HttpStatus.OK);
		}

		
		
		//-----------update event----------//
		
				@RequestMapping(value = "/event-update/{event_id}", method = RequestMethod.PUT)
				public ResponseEntity<Event> eventLecture(@PathVariable("event_id") long event_id, @RequestBody Event event) {
					System.out.println("Updating Event " + event_id);
					
					Event currentEvent = eventService.findById(event_id);
					
					if (currentEvent==null) {
						System.out.println("Event with id " + event_id + " not found");
						return new ResponseEntity<Event>(HttpStatus.NOT_FOUND);
					}

					currentEvent.setEvent_name(event.getEvent_name());
					currentEvent.setEvent_description(event.getEvent_description());
					currentEvent.setEvent_date(event.getEvent_date());
					currentEvent.setEvent_start_time(event.getEvent_start_time());
					currentEvent.setEvent_end_time(event.getEvent_end_time());

					eventService.updateEvent(currentEvent);
					return new ResponseEntity<Event>(currentEvent, HttpStatus.OK);
				}

		
		//------------ save holiday ------------//
		
		@RequestMapping(value="/saveholiday/",method=RequestMethod.POST)
		public ResponseEntity<Void> holidayLecture(@RequestBody Holiday holiday,UriComponentsBuilder ucBuilder)
		{
			holidayService.saveHoliday(holiday);
			
			return new ResponseEntity<>(HttpStatus.CREATED);
			
		}
		

		//------------- get all holidays -------------//
		
		@RequestMapping(value = "/getholidays/",method = RequestMethod.GET)
		public ResponseEntity<List<Holiday>> listallholidays()
		{
			List<Holiday> holidays=holidayService.findallholidays();
			
			if(holidays.isEmpty())
			{
				return new ResponseEntity<List<Holiday>>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<List<Holiday>>(holidays,HttpStatus.OK);
		}
		
		
		//----------------delete holiday--------------//
		
				@RequestMapping(value = "/holiday-del/{holiday_id}", method = RequestMethod.DELETE)
				public ResponseEntity<Holiday> deleteHoliday(@PathVariable("holiday_id") long holiday_id) {
					System.out.println("Fetching & Deleting holiday with id " + holiday_id);

					Holiday holiday = holidayService.findById(holiday_id);
					if (holiday == null) {
						System.out.println("Unable to delete. User with id " + holiday_id + " not found");
						return new ResponseEntity<Holiday>(HttpStatus.NOT_FOUND);
					}

					holidayService.deleteHolidayById(holiday_id);
					return new ResponseEntity<Holiday>(HttpStatus.NO_CONTENT);
				}
				
			
				//---------find holiday by id ------

						@RequestMapping(value = "/findholiday/{holiday_id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
						public ResponseEntity<Holiday> getHoliday(@PathVariable("holiday_id") long holiday_id) {
							System.out.println("Fetching holiday with id " + holiday_id);
							Holiday holiday = holidayService.findById(holiday_id);
							return new ResponseEntity<Holiday>(holiday, HttpStatus.OK);
						}
				
				
				//-----------update holiday----------//
				
				@RequestMapping(value = "/holiday-update/{holiday_id}", method = RequestMethod.PUT)
				public ResponseEntity<Holiday> updateHoliday(@PathVariable("holiday_id") long holiday_id, @RequestBody Holiday holiday) {
					System.out.println("Updating Holiday " + holiday_id);
					
					Holiday currentHoliday = holidayService.findById(holiday_id);
					
					if (currentHoliday==null) {
						System.out.println("Holiday with id " + holiday_id + " not found");
						return new ResponseEntity<Holiday>(HttpStatus.NOT_FOUND);
					}

					currentHoliday.setHoliday_id(holiday.getHoliday_id());
					currentHoliday.setHoliday_reason(holiday.getHoliday_reason());
					currentHoliday.setHoliday_date(holiday.getHoliday_date());
					currentHoliday.setHoliday_date(holiday.getHoliday_date());
				//	currentHoliday.setHoliday_end_time(holiday.getHoliday_end_time());

					holidayService.updateHoliday(currentHoliday);
					return new ResponseEntity<Holiday>(currentHoliday, HttpStatus.OK);
				}

				

				//------------ save student ------------//
				
					@RequestMapping(value="/savestudent/",method=RequestMethod.POST)
					public ResponseEntity<Void> createStudent(@RequestBody Student student,UriComponentsBuilder ucBuilder)
					{
						studentService.saveStudent(student);
						
						return new ResponseEntity<>(HttpStatus.CREATED);
					}
					

					//------------- get all students -------------//
					
					@RequestMapping(value = "/getstudents/",method = RequestMethod.GET)
					public ResponseEntity<List<Student>> listallstudents()
					{
						List<Student> students=studentService.findallstudents();
						
						if(students.isEmpty())
						{
							return new ResponseEntity<List<Student>>(HttpStatus.NO_CONTENT);
						}
						return new ResponseEntity<List<Student>>(students,HttpStatus.OK);
					}
					
					//------------- get students_login -------------//

					@RequestMapping(value = "/getstudentlogin/",method = RequestMethod.GET)
					public ResponseEntity<List<Login>> getallstudents()
					{
						List<Login> studentlogin=loginservice.findallstudents();
						
						if(studentlogin.isEmpty())
						{
							return new ResponseEntity<List<Login>>(HttpStatus.NO_CONTENT);
						}
						return new ResponseEntity<List<Login>>(studentlogin,HttpStatus.OK);
					}
					
					//------------- get students_login by login_type -------------//

					@RequestMapping(value = "/findloginbytype/{login_type}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
					public ResponseEntity<Login> getStudent(@PathVariable("login_type") String login_type) {
						System.out.println("Fetching student with type " + login_type);
						Login login = loginservice.findloginbytype(login_type);
						return new ResponseEntity<Login>(login, HttpStatus.OK);
					}
					
				//----------------delete student--------------//
					
					@RequestMapping(value = "/student-del/{student_id}", method = RequestMethod.DELETE)
					public ResponseEntity<Student> deleteStudent(@PathVariable("student_id") long student_id) {
						System.out.println("Fetching & Deleting student with id " + student_id);

						Student student = studentService.findById(student_id);
						if (student == null) {
							System.out.println("Unable to delete. User with id " + student_id + " not found");
							return new ResponseEntity<Student>(HttpStatus.NOT_FOUND);
						}

						studentService.deleteStudentById(student_id);
						return new ResponseEntity<Student>(HttpStatus.NO_CONTENT);
					}
					
				
					//---------find student by id ------

							@RequestMapping(value = "/findstudent/{student_id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
							public ResponseEntity<Student> getStudent(@PathVariable("student_id") long student_id) {
								System.out.println("Fetching student with id " + student_id);
								Student student = studentService.findById(student_id);
								return new ResponseEntity<Student>(student, HttpStatus.OK);
							}
					
					
					//-----------update student----------//
					
					@RequestMapping(value = "/student-update/{student_id}", method = RequestMethod.PUT)
					public ResponseEntity<Student> updateStudent(@PathVariable("student_id") long student_id, @RequestBody Student student) {
						System.out.println("Updating Student " + student_id);
						
						Student currentStudent = studentService.findById(student_id);
						
						if (currentStudent==null) {
							System.out.println("Student with id " + student_id + " not found");
							return new ResponseEntity<Student>(HttpStatus.NOT_FOUND);
						}
						currentStudent.setStudent_id(student.getStudent_id());
						currentStudent.setFull_name(student.getFull_name());
						currentStudent.setEmail_id(student.getEmail_id());
						currentStudent.setContact_no(student.getContact_no());
						currentStudent.setAddress(student.getAddress());
						currentStudent.setCourse_name(student.getCourse_name());
						currentStudent.setCourse_duration_from(student.getCourse_duration_from());
						currentStudent.setCourse_duration_to(student.getCourse_duration_to());
						currentStudent.setTotal_fees(student.getTotal_fees());
						currentStudent.setPaid_fees(student.getPaid_fees());
						currentStudent.setBalance_fees(student.getBalance_fees());
						studentService.updateStudent(currentStudent);
						return new ResponseEntity<Student>(currentStudent, HttpStatus.OK);
					}
					
					
					
}
