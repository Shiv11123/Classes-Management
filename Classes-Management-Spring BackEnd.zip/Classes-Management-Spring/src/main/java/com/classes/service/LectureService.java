package com.classes.service;

import java.util.List;

import com.classes.model.Lecture;

public interface LectureService {
	
List<Lecture> findalllectures();

void saveLecture(Lecture lecture);

void deleteLectureById(long lecture_id);

Lecture findById(long lecture_id);

void updateLecture(Lecture lecture);

}
