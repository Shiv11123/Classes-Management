package com.classes.service;

import java.util.List;

import com.classes.model.Holiday;

public interface HolidayService {
List<Holiday> findallholidays();
	
	void saveHoliday(Holiday Holiday);
	
	void deleteHolidayById(long holiday_id);

	Holiday findById(long holiday_id);

	void updateHoliday(Holiday holiday);

}
