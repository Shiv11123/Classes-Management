package com.classes.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.classes.dao.LectureDao;
import com.classes.model.Lecture;

@Service("lectureService")
@Transactional

public class LectureServiceImpl implements LectureService {
	@Autowired
	LectureDao lecturedao;


	@Override
	public List<Lecture> findalllectures() {
		// TODO Auto-generated method stub
		return lecturedao.findalllectures();
	}

	@Override
	public void saveLecture(Lecture lecture) {
		
		 lecturedao.saveLecture(lecture); 
		
	}

	@Override
	public void deleteLectureById(long lecture_id) {
		lecturedao.deleteLectureById(lecture_id);
		
	}

	@Override
	public Lecture findById(long lecture_id) {
		// TODO Auto-generated method stub
		return lecturedao.findById(lecture_id);
	}

	@Override
	public void updateLecture(Lecture lecture) {
		// TODO Auto-generated method stub
		lecturedao.updateLecture(lecture); 
		
	}
	

}
