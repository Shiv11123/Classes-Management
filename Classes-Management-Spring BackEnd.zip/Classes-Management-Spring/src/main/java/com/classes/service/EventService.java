package com.classes.service;
import java.util.List;

import com.classes.model.Event;
import com.classes.model.Lecture;

public interface EventService {
List<Event> findallevents();
	
	void saveEvent(Event event);

	void deleteEventById(long event_id);

	Event findById(long event_id);
	
	void updateEvent(Event event);

}
