package com.classes.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.classes.dao.StudentDao;
import com.classes.model.Student;

@Service("studentService")
@Transactional

public class StudentServiceImplementation implements StudentService {
	
	@Autowired
	StudentDao studentdao;

	@Override
	public List<Student> findallstudents() {
		// TODO Auto-generated method stub
		return studentdao.findallstudents();
	}

	@Override
	public void saveStudent(Student student) {
		// TODO Auto-generated method stub
		studentdao.saveStudent(student); 
	}

	@Override
	public void deleteStudentById(long student_id) {
		// TODO Auto-generated method stub
		studentdao.deleteStudentById(student_id);
	}

	@Override
	public Student findById(long student_id) {
		// TODO Auto-generated method stub
		return studentdao.findById(student_id);
	}

	@Override
	public void updateStudent(Student student) {
		// TODO Auto-generated method stub
		studentdao.updateStudent(student); 
		
	}

}
