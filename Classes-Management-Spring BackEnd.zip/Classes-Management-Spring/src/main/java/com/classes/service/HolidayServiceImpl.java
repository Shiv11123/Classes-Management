package com.classes.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.classes.dao.HolidayDao;
import com.classes.model.Holiday;

@Service("holidayService")
@Transactional


public class HolidayServiceImpl implements HolidayService
{
	@Autowired
	HolidayDao holidaydao;


	@Override
	public List<Holiday> findallholidays() {
		// TODO Auto-generated method stub
		return holidaydao.findallholidays();
	}

	@Override
	public void saveHoliday(Holiday holiday) {
		holidaydao.saveHoliday(holiday); 
		
	}

	@Override
	public void deleteHolidayById(long holiday_id) {
		holidaydao.deleteHolidayById(holiday_id);
		
	}

	@Override
	public Holiday findById(long holiday_id) {
		return holidaydao.findById(holiday_id);
	}

	@Override
	public void updateHoliday(Holiday holiday) {
		holidaydao.updateHoliday(holiday); 
		
	}
	
}