package com.classes.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.classes.dao.LoginDao;
import com.classes.model.Login;

@Service("loginservice")
@Transactional
public class LoginServiceImpl implements LoginService {
	
	@Autowired
	LoginDao logindao;
	
	@Override
	@Transactional
	public List<Login> findallstudents() {
		// TODO Auto-generated method stub
		return logindao.findallstudents();
	}

	@Override
	public Login findloginbytype(String login_type) {
		// TODO Auto-generated method stub
		return logindao.findloginbytype(login_type);
	}

	

}
