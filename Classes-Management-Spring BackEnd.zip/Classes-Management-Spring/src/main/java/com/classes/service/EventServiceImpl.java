package com.classes.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.classes.dao.EventDao;
import com.classes.model.Event;

@Service("eventService")
@Transactional

public class EventServiceImpl implements EventService{
	@Autowired
	EventDao eventdao;

	@Override
	public List<Event> findallevents() {
		// TODO Auto-generated method stub
		return eventdao.findallevents();
	}

	@Override
	public void saveEvent(Event event) {

		eventdao.saveEvent(event); 
		
	}

	@Override
	public void deleteEventById(long event_id) {
		// TODO Auto-generated method stub
		eventdao.deleteEventById(event_id);
		
	}

	@Override
	public Event findById(long event_id) {
		// TODO Auto-generated method stub
		return eventdao.findById(event_id);
	}

	@Override
	public void updateEvent(Event event) {
		// TODO Auto-generated method stub
		eventdao.updateEvent(event); 
		
	}

}
