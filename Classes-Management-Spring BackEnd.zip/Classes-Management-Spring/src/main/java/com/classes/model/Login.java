package com.classes.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name="LOGIN")

public class Login {
	
	@Id
	@Column(name="LOGIN_ID")
	private long login_id;

	@Column(name="UNAME")
	private String uname;

	@Column(name="PASSWORD")
	private String password;
	
	@Column(name="LOGIN_TYPE")
	private String login_type;

	public Login()
	{
		
	}

	public Login(long login_id, String uname, String password, String login_type) {
		super();
		this.login_id = login_id;
		this.uname = uname;
		this.password = password;
		this.login_type = login_type;
	}

	public long getLogin_id() {
		return login_id;
	}

	public void setLogin_id(long login_id) {
		this.login_id = login_id;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getLogin_type() {
		return login_type;
	}

	public void setLogin_type(String login_type) {
		this.login_type = login_type;
	}

	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (login_id ^ (login_id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Login other = (Login) obj;
		if (login_id != other.login_id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Login [login_id=" + login_id + ", uname=" + uname + ", password=" + password + ", login_type=" + login_type  + "]";
	}
	
	
}
