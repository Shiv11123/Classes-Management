package com.classes.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name="EVENT_DETAILS")

public class Event {

@Id
@Column(name="EVENT_ID")
private long event_id;

@Column(name="EVENT_NAME")
private String event_name;

@Column(name="EVENT_DESCRIPTION")
private String event_description;


@JsonFormat(pattern="yyyy-MM-dd")
@Column(name="EVENT_DATE")
private Date event_date;

@Column(name="EVENT_START_TIME")
private String event_start_time;

@Column(name="EVENT_END_TIME")
private String event_end_time;

public Event(){
	
}

public long getEvent_id() {
	return event_id;
}

public void setEvent_id(long event_id) {
	this.event_id = event_id;
}

public String getEvent_name() {
	return event_name;
}

public void setEvent_name(String event_name) {
	this.event_name = event_name;
}

public String getEvent_description() {
	return event_description;
}

public void setEvent_description(String event_description) {
	this.event_description = event_description;
}

public Date getEvent_date() {
	return event_date;
}

public void setEvent_date(Date event_date) {
	this.event_date = event_date;
}

public String getEvent_start_time() {
	return event_start_time;
}

public void setEvent_start_time(String event_start_time) {
	this.event_start_time = event_start_time;
}

public String getEvent_end_time() {
	return event_end_time;
}

public void setEvent_end_time(String event_end_time) {
	this.event_end_time = event_end_time;
}

public Event(long event_id, String event_name, String event_description, Date event_date, String event_start_time, String event_end_time)
{
	super();
	this.event_id=event_id;
	this.event_name=event_name;
	this.event_description=event_description;
	this.event_date=event_date;
	this.event_start_time=event_start_time;
	this.event_end_time=event_end_time;
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + (int) (event_id ^ (event_id >>> 32));
	return result;
}



@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Event other = (Event) obj;
	if (event_id != other.event_id)
		return false;
	return true;
}



@Override
public String toString() {
	return "Event [event_id=" + event_id + ", event_name=" + event_name + ", event_description=" + event_description + ", event_date=" + event_date + ", event_start_time=" + event_start_time
			+ ", event_end_time=" + event_end_time + "]";
}


}
