package com.classes.model;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name="HOLIDAY_DETAILS")

public class Holiday {
	@Id
	@Column(name="HOLIDAY_ID")
	private long holiday_id;
	
	@Column(name="HOLIDAY_REASON")
	private String holiday_reason;
	
	@JsonFormat(pattern="yyyy-MM-dd")
	@Column(name="HOLIDAY_DATE")
	private Date holiday_date;
	
	public Holiday() {
		
	}

	public long getHoliday_id() {
		return holiday_id;
	}

	public void setHoliday_id(long holiday_id) {
		this.holiday_id = holiday_id;
	}

	public String getHoliday_reason() {
		return holiday_reason;
	}

	public void setHoliday_reason(String holiday_reason) {
		this.holiday_reason = holiday_reason;
	}

	public Date getHoliday_date() {
		return holiday_date;
	}

	public void setHoliday_date(Date holiday_date) {
		this.holiday_date = holiday_date;
	}
	
	public Holiday(long holiday_id, String holiday_reason, Date holiday_date) {
		super();
		this.holiday_id = holiday_id;
		this.holiday_reason = holiday_reason;
		this.holiday_date = holiday_date;
		
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (holiday_id ^ (holiday_id >>> 32));
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Holiday other = (Holiday) obj;
		if (holiday_id != other.holiday_id)
			return false;
		return true;
	}



	@Override
	public String toString() {
		return "Holiday [holiday_id=" + holiday_id + ", holiday_reason=" + holiday_reason + ", holiday_date=" + holiday_date + "]";
	}
}
