package com.classes.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name="LECTURE_DETAILS")
public class Lecture {
	
	@Id
	@Column(name="LECTURE_ID")
	private long lecture_id;
	
	@Column(name="LECTURE_NAME")
	private String lecture_name;
	
	@Column(name="FACULTY_NAME")
	private String faculty_name;
	
	@JsonFormat(pattern="yyyy-MM-dd")
	@Column(name="LECTURE_DATE")
	private Date lecture_date;
	
	@Column(name="LECTURE_START_TIME")
	private String lecture_start_time;
	
	@Column(name="LECTURE_END_TIME")
	private String lecture_end_time;
	
	public Lecture()
	{
		
	}
//	@OneToMany(mappedBy = "members",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
//	private List<Reciept> reciepts;
//	

	

	public long getLecture_id() {
		return lecture_id;
	}
	
	public void setLecture_id(long lecture_id) {
		this.lecture_id = lecture_id;
	}

	public String getLecture_name() {
		return lecture_name;
	}

	public void setLecture_name(String lecture_name) {
		this.lecture_name = lecture_name;
	}
	
	public String getFaculty_name() {
		return faculty_name;
	}

	public void setFaculty_name(String faculty_name) {
		this.faculty_name = faculty_name;
	}

	public Date getLecture_date() {
		return lecture_date;
	}

	public void setLecture_date(Date lecture_date) {
		this.lecture_date = lecture_date;
	}

	public String getLecture_start_time() {
		return lecture_start_time;
	}

	public void setLecture_start_time(String lecture_start_time) {
		this.lecture_start_time = lecture_start_time;
	}

	public String getLecture_end_time() {
		return lecture_end_time;
	}

	public void setLecture_end_time(String lecture_end_time) {
		this.lecture_end_time = lecture_end_time;
	}

	public Lecture(long lecture_id, String lecture_name, String faculty_name, Date lecture_date, String lecture_start_time, String lecture_end_time) {
		super();
		this.lecture_id = lecture_id;
		this.lecture_name = lecture_name;
		this.faculty_name = faculty_name;
		this.lecture_date = lecture_date;
		this.lecture_start_time = lecture_start_time;
		this.lecture_end_time = lecture_end_time;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (lecture_id ^ (lecture_id >>> 32));
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Lecture other = (Lecture) obj;
		if (lecture_id != other.lecture_id)
			return false;
		return true;
	}



	@Override
	public String toString() {
		return "Lecture [lecture_id=" + lecture_id + ", lecture_name=" + lecture_name + ", faculty_name=" + faculty_name + ", lecture_date=" + lecture_date + ", lecture_start_time=" + lecture_start_time
				+ ", lecture_end_time=" + lecture_end_time + "]";
	}

}

