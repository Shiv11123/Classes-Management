package com.classes.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name="STUDENT_DETAILS")
public class Student {
	@Id
	@Column(name="STUDENT_ID")
	private long student_id;
	
	@Column(name="FULL_NAME")
	private String full_name;
	
	@Column(name="EMAIL_ID")
	private String email_id;
	
	@Column(name="CONTACT_NO")
	private long contact_no;
	
	@Column(name="ADDRESS")
	private String address;
	
	@Column(name="COURSE_NAME")
	private String course_name;
	
	@JsonFormat(pattern="yyyy-MM-dd")
	@Column(name="COURSE_DURATION_FROM")
	private Date course_duration_from;
	
	@JsonFormat(pattern="yyyy-MM-dd")
	@Column(name="COURSE_DURATION_TO")
	private Date course_duration_to;
	
	@Column(name="TOTAL_FEES")
	private long total_fees;
	
	@Column(name="PAID_FEES")
	private long paid_fees;
	
	@Column(name="BALANCE_FEES")
	private long balance_fees;
	
	public Student()
	{
		
	}
	
	public long getStudent_id() {
		return student_id;
	}

	public void setStudent_id(long student_id) {
		this.student_id = student_id;
	}

	public String getFull_name() {
		return full_name;
	}

	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public long getContact_no() {
		return contact_no;
	}

	public void setContact_no(long contact_no) {
		this.contact_no = contact_no;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCourse_name() {
		return course_name;
	}

	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}

	public Date getCourse_duration_from() {
		return course_duration_from;
	}

	public void setCourse_duration_from(Date course_duration_from) {
		this.course_duration_from = course_duration_from;
	}

	public Date getCourse_duration_to() {
		return course_duration_to;
	}

	public void setCourse_duration_to(Date course_duration_to) {
		this.course_duration_to = course_duration_to;
	}

	public long getTotal_fees() {
		return total_fees;
	}

	public void setTotal_fees(long total_fees) {
		this.total_fees = total_fees;
	}

	public long getPaid_fees() {
		return paid_fees;
	}

	public void setPaid_fees(long paid_fees) {
		this.paid_fees = paid_fees;
	}

	public long getBalance_fees() {
		return balance_fees;
	}

	public void setBalance_fees(long balance_fees) {
		this.balance_fees = balance_fees;
	}

	
	

	public Student(long student_id, String full_name, String email_id, long contact_no, String address,
			String course_name, Date course_duration_from, Date course_duration_to, long total_fees, long paid_fees,
			long balance_fees) {
		super();
		this.student_id = student_id;
		this.full_name = full_name;
		this.email_id = email_id;
		this.contact_no = contact_no;
		this.address = address;
		this.course_name = course_name;
		this.course_duration_from = course_duration_from;
		this.course_duration_to = course_duration_to;
		this.total_fees = total_fees;
		this.paid_fees = paid_fees;
		this.balance_fees = balance_fees;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (student_id ^ (student_id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (student_id != other.student_id)
			return false;
		return true;
	}



	@Override
	public String toString() {
		return "Student [student_id=" + student_id + ", full_name="+full_name+", email_id="+email_id+". contact_no="+contact_no+", address="+address+", course_name="+course_name+", course_duration_from="+course_duration_from+", course_duration_to="+course_duration_to+", total_fees="+total_fees+", paid_fees="+paid_fees+", balance_fees="+balance_fees+"]";
	}
	
}
