package com.classes.dao;

import java.util.List;
import com.classes.model.Event;
import com.classes.model.Event;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin(origins = "http://localhost:4200")
@Repository
public class EventDaoImpl implements EventDao {
	private static final Logger logger = LoggerFactory.getLogger(EventDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
		}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Event> findallevents() {
		// TODO Auto-generated method stub
		Session session=this.sessionFactory.getCurrentSession();
		List<Event> eventlist=session.createQuery("From Event").list();
		for(Event event:eventlist)
		{
			logger.info("event List::"+event);
		}
		return eventlist;
	}

	@Override
	public void saveEvent(Event event) {
		// TODO Auto-generated method stub
		Session session=this.sessionFactory.getCurrentSession();
		session.persist(event);
		logger.info("Person saved successfully, Event Details="+event);
	}

	@Override
	public void deleteEventById(long event_id) {
		logger.info(" Del ID : "+event_id);
		Session session = this.sessionFactory.getCurrentSession();
		Event event = (Event) session.load(Event.class, new Long(event_id));
		
		session.delete(event);
		
		logger.info("Event deleted successfully, event details="+event);
		
	}

	@Override
	public Event findById(long event_id) {
		logger.info("ID : "+event_id);
		Session session = this.sessionFactory.getCurrentSession();
		Event event = (Event) session.load(Event.class, new Long(event_id));
		logger.info("Event loaded successfully, Event details="+event);
		return event;
	}

	@Override
	public void updateEvent(Event event) {
		Session session = this.sessionFactory.getCurrentSession();
		session.update(event);
		logger.info("update successfully"+event);
		
	}

}
