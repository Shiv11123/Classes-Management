package com.classes.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.classes.model.Lecture;
import com.classes.model.Login;

@Repository
public class LoginDaoImpl implements LoginDao {

	private static final Logger logger = LoggerFactory.getLogger(EventDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
		}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Login> findallstudents() {
		// TODO Auto-generated method stub
				Session session=this.sessionFactory.getCurrentSession();
				List<Login> loginlist=session.createQuery("From Login").list();
				for(Login login:loginlist)
				{
					logger.info("login List::"+login);
				}
				return loginlist;
	}


	@Override
	public Login findloginbytype(String login_type) {
		// TODO Auto-generated method stub
				logger.info("TYPE : "+login_type);
				Session session = this.sessionFactory.getCurrentSession();
				Login login = (Login) session.load(Login.class, new String(login_type));
				logger.info("Login loaded successfully, Login details="+login);
				return login;
	}

}
