package com.classes.dao;

import java.util.List;

import com.classes.model.Student;

public interface StudentDao {
	List<Student> findallstudents();

	void saveStudent(Student student);

	void deleteStudentById(long student_id);
		
	Student findById(long student_id);

	void updateStudent(Student student);

}
