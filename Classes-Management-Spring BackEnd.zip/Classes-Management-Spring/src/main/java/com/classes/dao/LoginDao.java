package com.classes.dao;

import java.util.List;

import com.classes.model.Login;


public interface LoginDao {

	List<Login> findallstudents();

	Login findloginbytype(String login_type);
	
}
