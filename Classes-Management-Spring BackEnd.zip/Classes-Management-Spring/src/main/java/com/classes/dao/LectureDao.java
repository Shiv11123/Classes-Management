package com.classes.dao;
import java.util.List;

import com.classes.model.Lecture;

public interface LectureDao {
List<Lecture> findalllectures();

void saveLecture(Lecture lecture);

void deleteLectureById(long lecture_id);
	
Lecture findById(long lecture_id);

void updateLecture(Lecture lecture);
}
