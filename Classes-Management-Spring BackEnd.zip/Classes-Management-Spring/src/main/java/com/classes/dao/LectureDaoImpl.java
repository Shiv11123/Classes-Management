package com.classes.dao;

import java.util.List;
import javax.persistence.EntityNotFoundException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;
import com.classes.model.Lecture;

@CrossOrigin(origins = "http://localhost:4200")
@Repository
public class LectureDaoImpl implements LectureDao {
	private static final Logger logger = LoggerFactory.getLogger(LectureDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
		}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Lecture> findalllectures() {
		// TODO Auto-generated method stub
		Session session=this.sessionFactory.getCurrentSession();
		List<Lecture> lecturelist=session.createQuery("From Lecture").list();
		for(Lecture lecture:lecturelist)
		{
			logger.info("member List::"+lecture);
		}
		
		return lecturelist;
	}
	
	@Override
	public void saveLecture(Lecture lecture) {
		Session session=this.sessionFactory.getCurrentSession();
		session.persist(lecture);
		logger.info("Lecture saved successfully, Lecture Details="+lecture);
	}

	@Override
	public void deleteLectureById(long lecture_id) {
		logger.info(" Del ID : "+lecture_id);
		Session session = this.sessionFactory.getCurrentSession();
		Lecture lecture = (Lecture) session.load(Lecture.class, new Long(lecture_id));
		
		session.delete(lecture);
		
		logger.info("Lecture deleted successfully, lecture details="+lecture);
	}

	
	@Override
	public Lecture findById(long lecture_id) {
		// TODO Auto-generated method stub
		logger.info("ID : "+lecture_id);
		Session session = this.sessionFactory.getCurrentSession();
		Lecture lecture = (Lecture) session.load(Lecture.class, new Long(lecture_id));
		logger.info("Lecture loaded successfully, Lecture details="+lecture);
		return lecture;
	}
	
	@Override
	public void updateLecture(Lecture lecture) {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		session.update(lecture);
		logger.info("update successfully"+lecture);
	}
	

}
