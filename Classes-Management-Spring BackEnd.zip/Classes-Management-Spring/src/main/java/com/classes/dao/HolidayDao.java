package com.classes.dao;

import java.util.List;

import com.classes.model.Holiday;

public interface HolidayDao {
List<Holiday> findallholidays();
	
	void saveHoliday(Holiday member);

	void deleteHolidayById(long holiday_id);

	Holiday findById(long holiday_id);

	void updateHoliday(Holiday holiday);

}
