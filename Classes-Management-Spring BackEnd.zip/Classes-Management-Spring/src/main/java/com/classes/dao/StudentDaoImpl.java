package com.classes.dao;

import java.util.List;
import javax.persistence.EntityNotFoundException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;
import com.classes.model.Student;

@CrossOrigin(origins = "http://localhost:4200")
@Repository
public class StudentDaoImpl implements StudentDao {
	private static final Logger logger = LoggerFactory.getLogger(StudentDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
		}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Student> findallstudents() {
		Session session=this.sessionFactory.getCurrentSession();
		List<Student> studentlist=session.createQuery("From Student").list();
		for(Student student:studentlist)
		{
			logger.info("member List::"+student);
		}
		
		return studentlist;
	}

	@Override
	public void saveStudent(Student student) {
		Session session=this.sessionFactory.getCurrentSession();
		session.persist(student);
		logger.info("Student saved successfully, Student Details="+student);
		
	}

	@Override
	public void deleteStudentById(long student_id) {
		logger.info(" Del ID : "+student_id);
		Session session = this.sessionFactory.getCurrentSession();
		Student student = (Student) session.load(Student.class, new Long(student_id));
		
		session.delete(student);
		
		logger.info("Student deleted successfully, student details="+student);
		
	}

	@Override
	public Student findById(long student_id) {
		logger.info("ID : "+student_id);
		Session session = this.sessionFactory.getCurrentSession();
		Student student = (Student) session.load(Student.class, new Long(student_id));
		logger.info("Student loaded successfully, Student details="+student);
		return student;
	}

	@Override
	public void updateStudent(Student student) {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		session.update(student);
		logger.info("update successfully"+student);
		
	}

}
