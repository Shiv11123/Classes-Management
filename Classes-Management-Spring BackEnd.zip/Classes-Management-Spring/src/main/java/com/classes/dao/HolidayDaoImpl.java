package com.classes.dao;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;
import com.classes.model.Holiday;
import com.classes.model.Holiday;

@CrossOrigin(origins = "http://localhost:4200")
@Repository
public class HolidayDaoImpl implements HolidayDao{
	private static final Logger logger = LoggerFactory.getLogger(HolidayDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
		}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Holiday> findallholidays() {
		// TODO Auto-generated method stub
				Session session=this.sessionFactory.getCurrentSession();
				List<Holiday> holidaylist=session.createQuery("From Holiday").list();
				for(Holiday holiday:holidaylist)
				{
					logger.info("holiday List::"+holiday);
				}
				
				return holidaylist;
	}

	@Override
	public void saveHoliday(Holiday holiday) {
		// TODO Auto-generated method stub
		Session session=this.sessionFactory.getCurrentSession();
		session.persist(holiday);
		logger.info("Holiday saved successfully, Holiday Details="+holiday);
		
	}

	@Override
	public void deleteHolidayById(long holiday_id) {
		logger.info(" Del ID : "+holiday_id);
		Session session = this.sessionFactory.getCurrentSession();
		Holiday holiday = (Holiday) session.load(Holiday.class, new Long(holiday_id));
		
		session.delete(holiday);
		
		logger.info("Holiday deleted successfully, holiday details="+holiday);
		
	}

	@Override
	public Holiday findById(long holiday_id) {
		logger.info("ID : "+holiday_id);
		Session session = this.sessionFactory.getCurrentSession();
		Holiday holiday = (Holiday) session.load(Holiday.class, new Long(holiday_id));
		logger.info("Holiday loaded successfully, Holiday details="+holiday);
		return holiday;
	}

	@Override
	public void updateHoliday(Holiday holiday) {
		Session session = this.sessionFactory.getCurrentSession();
		session.update(holiday);
		logger.info("update successfully"+holiday);
		
	}

}
